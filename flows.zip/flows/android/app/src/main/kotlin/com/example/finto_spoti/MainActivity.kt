package com.example.flows

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
