# flows

Progetto d'esame di Sechi Simone

## Cosa è

Questo progetto è un'applicazione per ascoltare musica in streaming senza doverla scaricare sul proprio dispositivo
